package project;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@Path("/list")
public class ProjectList {

	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getProjectList()
	{
		
		String jsonResponse="{\"status\":\"success\",\"responsedata\":{\"projects\":[{\"id\":1,\"title\":\"project 0\",\"desc\":\"description of project\"},{\"id\":1,\"project 1\":\"mystery\",\"desc\":\"description of project\"},\r\n" + 
				"{\"id\":1,\"title\":\"project 2\",\"desc\":\"description of project\"},{\"id\":1,\"title\":\"project 3\",\"desc\":\"description of project\"},{\"id\":1,\"title\":\"project 4\",\"desc\":\"description of project\"}\r\n" + 
				"]},\"violations\":[]}";
		
		return jsonResponse;
	}
	
}
